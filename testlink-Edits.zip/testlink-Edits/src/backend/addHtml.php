<?php



	///کدهای زیر مربوط به افزودن html سفارشی به صفحه testCase های testLink است
	///این کد در فایل های اصلی testlink قرار داده شده است
   
		$basePath = config_get('restAPI')->basePath;
		$basePath =  "." . $basePath;	
		$smarty->assign('baseRoute', $basePath);  
		$smarty->assign('apiKey', 'c8a540fce43725f6ce34f6cc8f991f67');
		$sortFilterHtml = $smarty->fetch($template_dir.'/tcSort.tpl');  
		moveTestCasesViewer($db, $smarty, $tproject_mgr, $tree_mgr, $args, null, $sortFilterHtml);